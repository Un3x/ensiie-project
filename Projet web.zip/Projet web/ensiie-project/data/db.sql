CREATE TABLE "utilisateurs" (
    user_id SERIAL PRIMARY KEY ,
    password VARCHAR NOT NULL ,
    pseudo VARCHAR NOT NULL ,
    birthday date,
    statut integer,

);


CREATE TABLE "concert"
(
    concert_id SERIAL PRIMARY KEY ,
    nom VARCHAR NOT NULL ,
    artiste_id INT ,
    nom_artiste VARCHAR NOT NULL ,
    salle_id INT ,
    nb_reservation INT ,
    description VARCHAR,
    date DATE,
);



CREATE TABLE "salle"
(
    salle_id SERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    ville VARCHAR NOT NULL,
    adresse varchar not null,
    capacity int
);


CREATE TABLE "artiste"
(
    artiste_id SERIAL PRIMARY KEY ,
    nom_artiste VARCHAR NOT NULL ,
    genre VARCHAR NOT NULL ,
    description_artiste VARCHAR
);


CREATE TABLE "liste"
(
    liste_id SERIAL PRIMARY KEY ,
    user_id INT ,
    concert_id INT
);




INSERT INTO "concert"(concert_id, nom, artiste_id, nom_artiste, salle_id, nb_reservation, description, date) VALUES (00001,
 'DEUX FRÈRES',00001,'PNL',00001,1000,'PNL (sigle de Peace N’ Lovés) est un groupe de rap français indépendant, composé de deux frères, Ademo et N.O.S (de leurs vrais noms Tarik et Nabil Andrieu), originaires de la cité des Tarterêts à Corbeil-Essonnes.',14/05/2019);
INSERT INTO "concert"(concert_id, nom, artiste_id, nom_artiste, salle_id, nb_reservation, description, date) VALUES (00002,
'DOUBLE HÉLICE 3',00002, 'Caballero & Jean-Jass', 00001, 1000, 'Après le succès des volets 1 et 2, le duo incontournable du rap belge, Caballero et JeanJass, est de retour avec «Double Hélice 3» ! Ils nous offrent un projet cohérent aux recettes désormais maîtrisées et aux sonorités futuristes, un mélange rafraîchissant et intense de ce qui se fait de mieux.', 01/09/2019);
INSERT INTO "concert" (concert_id, nom, artiste_id, nom_artiste, salle_id, nb_reservation, description, date) VALUES (00003,
'J.O.$',00003, 'Josman', 00001, 1000, 'Avec deux mixtapes et plusieurs clips cumulant des millions de vues sur youtube, Josman est décrit comme l''un des meilleurs espoirs du Rap Français. Celui qui fit ses premiers pas dans le rap en écumant les opens mics a vu sa côte exploser en 2016, avec le titre ‘Dans le vide'', extrait de sa deuxième mixtape ‘Matrix', 30/09/2019);
INSERT INTO "salle"(salle_id, name, ville, adresse, capacity) VALUES (00001, La Cigale, Paris, '120 Boulevard de Rochechouart, 75018 Paris', 954);
INSERT INTO "artiste"(artiste_id, nom_artiste, genre, description_artiste) VALUES (00001, 'PNL', 'Rap', 'PNL (sigle de Peace N’ Lovés) est un groupe de rap français indépendant, composé de deux frères, Ademo et N.O.S (de leurs vrais noms Tarik et Nabil Andrieu), originaires de la cité des Tarterêts à Corbeil-Essonnes. Le groupe se caractérise par une absence totale d''interview dans la presse, ainsi que par des clips cinématographiques novateurs en France, tournés à travers le monde (Japon, États-Unis, Italie, Islande, Afrique du Sud, Namibie...) dès ses débuts en 2015. En 2016, PNL est classé 8e meilleur vendeur d''albums en France.');
INSERT INTO "artiste"(artiste_id, nom_artiste, genre, description_artiste) VALUES (00002, 'Caballero & Jean-Jass', 'Rap', 'Déjantés mais toujours authentiques, Caballero & JeanJass ont remarquablement attiré l’attention de la jeune génération qui les a rapidement érigés en figures de proue de la nouvelle scène hip-hop belge. Amplement plébiscité par le public, le duo sera présent sur les plus grandes scènes pour la tournée «Double Hélice Tour.');
INSERT INTO "artiste"(artiste_id, nom_artiste, genre, description_artiste) VALUES (00003, 'Josman', 'Rap', 'Josman, de son vrai nom José Nzengo, est un rappeur et producteur français né le 28 octobre 1992, de parents angolais et congolais.');